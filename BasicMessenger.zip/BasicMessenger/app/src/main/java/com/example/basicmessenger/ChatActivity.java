package com.example.basicmessenger;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    public static final String EXTRA_CHAT_ID = "CHAT_ID";
    private static final int PERMISSION_REQUEST_SMS = 101;

    ListView lvMessages;
    EditText etNewMsg;
    Button btnSend, btnBack;
    TextView tvHeader;

    ArrayList<String> messagesList = new ArrayList<>();
    ArrayAdapter<String> adapter;
    DatabaseReference chatRef;
    String targetPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        lvMessages = findViewById(R.id.lvMessages);
        etNewMsg = findViewById(R.id.etNewMsg);
        btnSend = findViewById(R.id.btnSendMsg);
        btnBack = findViewById(R.id.btnBack);
        tvHeader = findViewById(R.id.tvChatPartner);

        String chatId = getIntent().getStringExtra("CHAT_ID");

        if (chatId == null) {
            Toast.makeText(this, "Error: Chat not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String[] parts = chatId.split("_");
        if (parts.length > 1) {
            targetPhoneNumber = parts[1];
            if (tvHeader != null) {
                tvHeader.setText(targetPhoneNumber);
            }
        }

        chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, messagesList);
        lvMessages.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        chatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                messagesList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String message = ds.getValue(String.class);
                    messagesList.add(message);
                }
                adapter.notifyDataSetChanged();
                lvMessages.setSelection(adapter.getCount() - 1);
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });

        btnSend.setOnClickListener(v -> {
            String text = etNewMsg.getText().toString().trim();
            if (!text.isEmpty()) {
                chatRef.push().setValue("Me: " + text);

                if (targetPhoneNumber != null && !targetPhoneNumber.isEmpty()) {
                    checkPermissionAndSendSms(targetPhoneNumber, text);
                }
                etNewMsg.setText("");
            }
        });
    }

    private void checkPermissionAndSendSms(String phone, String msg) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SMS);
        } else {
            sendRealSms(phone, msg);
        }
    }

    private void sendRealSms(String phone, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}