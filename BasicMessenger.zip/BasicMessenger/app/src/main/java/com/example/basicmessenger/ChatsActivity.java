package com.example.basicmessenger;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ChatsActivity extends AppCompatActivity {
    ListView lvChats;
    ArrayList<String> chatList = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chats);

        lvChats = findViewById(R.id.lvChats);
        String myUid = FirebaseAuth.getInstance().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Chats");

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, chatList);
        lvChats.setAdapter(adapter);


        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                chatList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    if (ds.getKey().contains(myUid)) {
                        chatList.add(ds.getKey());
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError error) {}
        });


        lvChats.setOnItemClickListener((parent, view, position, id) -> {
            String chatId = chatList.get(position);
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("CHAT_ID", chatId);
            startActivity(intent);
        });
    }
}