package com.example.basicmessenger;

import android.Manifest;import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddContactActivity extends AppCompatActivity {

    private EditText etName, etPhone, etMessage;
    private Button btnSendFirst;
    private DatabaseReference db;


    private static final int PERMISSION_REQUEST_SMS = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_contact);

        initViews();
        db = FirebaseDatabase.getInstance().getReference();


        btnSendFirst.setOnClickListener(v -> handleSendAction());
        findViewById(R.id.btnBack).setOnClickListener(v -> {
            finish();
        });
    }

    private void initViews() {
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etMessage = findViewById(R.id.etMessage);
        btnSendFirst = findViewById(R.id.btnSendFirst);
    }

    private void handleSendAction() {
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String msg = etMessage.getText().toString().trim();


        if (name.isEmpty()) {
            etName.setError("Name is required");
            etName.requestFocus();
            return;
        }
        if (phone.isEmpty()) {
            etPhone.setError("Phone number is required");
            etPhone.requestFocus();
            return;
        }
        if (msg.isEmpty()) {
            etMessage.setError("Message is required");
            etMessage.requestFocus();
            return;
        }


        saveContactToFirebase(name, phone, msg);


        checkPermissionAndSendSms(phone, msg);
    }

    private void saveContactToFirebase(String name, String phone, String msg) {
        String myUid = FirebaseAuth.getInstance().getUid();

        if (myUid == null) return;


        db.child("Users").child(myUid).child("Contacts").child(phone).setValue(name);


        String chatKey = myUid + "_" + phone;


        db.child("Chats").child(chatKey).push().setValue("Me: " + msg);
    }

    private void checkPermissionAndSendSms(String phone, String msg) {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {


            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    PERMISSION_REQUEST_SMS);
        } else {

            sendRealSms(phone, msg);
        }
    }

    private void sendRealSms(String phone, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(phone, null, msg, null, null);

            Toast.makeText(this, "SMS Sent & Contact Saved!", Toast.LENGTH_SHORT).show();


            finish();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User clicked "Allow", retry sending
                String phone = etPhone.getText().toString();
                String msg = etMessage.getText().toString();
                sendRealSms(phone, msg);
            } else {
                Toast.makeText(this, "Permission denied. Cannot send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
