package com.example.basicmessenger;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.content.Intent;
import java.util.ArrayList;

public class ContactsListActivity extends AppCompatActivity {
    ListView listView;
    Button btnBack, btnAddContact;
    ArrayList<String> displayNames = new ArrayList<>();

    ArrayList<String> phoneNumbers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_list);

        listView = findViewById(R.id.lvContacts);
        btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
        Button btnAddContact = findViewById(R.id.btnAddContact);
        btnAddContact.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddContactActivity.class);
            startActivity(intent);
        });
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();


            if (currentUser == null) {
                Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }


            String myUid = currentUser.getUid();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(myUid).child("Contacts");


            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayNames);
            listView.setAdapter(adapter);

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    displayNames.clear();
                    phoneNumbers.clear();

                    for (DataSnapshot ds : snapshot.getChildren()) {

                        String name = ds.getValue(String.class);

                        String phone = ds.getKey();


                        displayNames.add(name + " (" + phone + ")");


                        phoneNumbers.add(phone);
                    }
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(DatabaseError error) {

                }
            });


            listView.setOnItemClickListener((parent, view, position, id) -> {

                String selectedPhone = phoneNumbers.get(position);


                String chatId = myUid + "_" + selectedPhone;


                Intent intent = new Intent(ContactsListActivity.this, ChatActivity.class);
                intent.putExtra("CHAT_ID", chatId);


                intent.putExtra("phone_key", selectedPhone);

                startActivity(intent);
            });
        }
    }
