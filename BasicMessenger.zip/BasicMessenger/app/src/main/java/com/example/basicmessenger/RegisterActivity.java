package com.example.basicmessenger;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    EditText etEmail, etPass;
    FirebaseAuth mAuth;
    Button btnBack, btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mAuth = FirebaseAuth.getInstance();
        etEmail = findViewById(R.id.etRegEmail);
        etPass = findViewById(R.id.etRegPassword);
        btnBack = findViewById(R.id.btnBack);
        btnRegister = findViewById(R.id.btnDoRegister);


        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        } else {
            Log.e("RegisterActivity", "Button btnBack not found in layout!");
        }

        if (btnRegister != null) {
            btnRegister.setOnClickListener(v -> {
                String email = etEmail.getText().toString().trim();
                String password = etPass.getText().toString().trim();

                if (!email.isEmpty() && !password.isEmpty()) {

                    mAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(this, task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RegisterActivity.this, "Registration Success!", Toast.LENGTH_SHORT).show();


                                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    String errorMessage = task.getException() != null ? task.getException().getMessage() : "Unknown Error";
                                    Toast.makeText(RegisterActivity.this, "Error: " + errorMessage, Toast.LENGTH_LONG).show();
                                }
                            });
                } else {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
